-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Dim 09 Avril 2017 à 10:55
-- Version du serveur :  5.5.54-0+deb8u1
-- Version de PHP :  5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `ban`
--

-- --------------------------------------------------------

--
-- Structure de la table `ban`
--

CREATE TABLE IF NOT EXISTS `ban` (
  `UUID` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `TIME` varchar(255) NOT NULL,
  `REASON` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `banTemp`
--

CREATE TABLE IF NOT EXISTS `banTemp` (
  `UUID` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `TIME` bigint(20) NOT NULL,
  `REASON` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `mute`
--

CREATE TABLE IF NOT EXISTS `mute` (
  `UUID` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `TIME` varchar(255) NOT NULL,
  `REASON` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `muteTemp`
--

CREATE TABLE IF NOT EXISTS `muteTemp` (
  `UUID` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `TIME` bigint(20) NOT NULL,
  `REASON` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
